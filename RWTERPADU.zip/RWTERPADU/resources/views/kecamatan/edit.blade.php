<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/kecamatan/update/{{$kecamatan->id}}" method="post">
    <table align="center">
        @csrf
        @method('PUT')
        <tr>
            <td>Nama Kecamatan</td>
            <td>
                <input type="text" name="nama_kecamatan" value="{{$kecamatan->nama_kecamatan}}">
            </td>
        </tr>
        <tr>
            <td>Nama Camat</td>
            <td>
                <input type="text" name="nama_camat" value="{{$kecamatan->nama_camat}}">
            </td>
        </tr>
        <tr>
            <td>Masa Jabatan</td>
            <td>
                <input type="text" name="masa_jabatan" value="{{$kecamatan->masa_jabatan}}">
            </td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td>
                <input type="text" name="no_telp" value="{{$kecamatan->no_telp}}">
            </td>
        </tr>
        <tr>
            <td>Email</td>
            <td>
                <input type="email" name="email" value="{{$kecamatan->email}}">
            </td>
        </tr>
        <tr>
            <td>
                <button type="submit">Submit</button>
            </td>
        </tr>
    </table>
</form>
</body>
</html>