<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/petugas/update/{{$petugas->id}}" method="post">
    <table align="center">
        @csrf
        @method('PUT')
        <tr>
            <td>Nama Petugas</td>
            <td>
                <input type="text" name="nama_petugas" value="{{$petugas->nama_petugas}}">
            </td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td>
                <input type="text" name="no_telp" value="{{$petugas->no_telp}}">
            </td>
        </tr>
        <tr>
            <td>Email</td>
            <td>
                <input type="text" name="email" value="{{$petugas->email}}">
            </td>
        </tr>
        <tr>
            <td>
                <button type="submit">Submit</button>
            </td>
        </tr>
    </table>
</form>
</body>
</html>