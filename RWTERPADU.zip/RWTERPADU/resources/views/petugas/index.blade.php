<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table>
        <thead>
            <th>NO</th>
            <th>Nama Petugas</th>
            <th>No Telpon</th>
            <th>Email</th>
            <th>Action</th>
        </thead>
       @foreach ($petugas as $isi=> $a)
        <tbody>
            <tr>
                <td>{{$isi+1}}</td>
                <td>{{$a->nama_petugas}}</td>
                <td>{{$a->no_telp}}</td>
                <td>{{$a->email}}</td>
                <td><a href="/petugas/edit/{{$a->id}}">Edit</a>
                    <a href="/petugas/destroy/{{$a->id}}">Hapus</a>
                </td>
            </tr>
           
        @endforeach
    </table>
    <a href="/petugas/create">Tambah</a>
</body>
</html>