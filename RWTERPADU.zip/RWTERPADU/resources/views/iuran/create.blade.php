<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/iuran/store" method="post">
    @csrf
    <tr>
        <td>Tanggal Update Iuran</td>
        <input type="date" name="tanggal_update_iuran">
    </tr>
    <tr>
        <td>Nominal Iuran</td>
        <input type="number" name="nominal_iuran">
    </tr>
    <tr>
        <button type="submit">Simpan</button>
    </tr>
</form>
</body>
</html>