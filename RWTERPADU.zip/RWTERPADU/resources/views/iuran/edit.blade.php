<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/iuran/update/{{$iuran->id}}" method="post">
    <table align="center">
        @csrf
        @method('PUT')
        <tr>
            <td>Tanggal Update Iuran</td>
            <td>
                <input type="text" name="nama_iuran" value="{{$iuran->tanggal_update_iuran}}">
            </td>
        </tr>
        <tr>
            <td>Nominal Iuran</td>
            <td>
                <input type="text" name="no_telp" value="{{$iuran->nominal_iuran}}">
            </td>
        </tr>
        <tr>
            <td>
                <button type="submit">Submit</button>
            </td>
        </tr>
    </table>
</form>
</body>
</html>