<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table>
        <thead>
            <th>NO</th>
            <th>Tanggal Update Iuran</th>
            <th>Nominal Iuran</th>
        </thead>
       @foreach ($iuran as $isi=> $a)
        <tbody>
            <tr>
                <td>{{$isi+1}}</td>
                <td>{{$a->tanggal_update_iuran}}</td>
                <td>{{$a->nominal_iuran}}</td>
                <td><a href="/iuran/edit/{{$a->id}}">Edit</a>
                    <a href="/iuran/destroy/{{$a->id}}">Hapus</a>
                </td>
            </tr>
        @endforeach
    </table>
    <a href="/iuran/create">Tambah</a>
</body>
</html>