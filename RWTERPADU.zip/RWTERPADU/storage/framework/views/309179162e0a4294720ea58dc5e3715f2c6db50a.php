<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <td>Nama RT</td>
            <td> : <?php echo e($rt->nama_rt); ?></td>
        </tr>
        <tr>
            <td>Masa Jabatan</td>
            <td> : <?php echo e($rt->masa_jabatan); ?></td>
        </tr>
        <tr>
            <td>No Telp</td>
            <td> : <?php echo e($rt->no_telp); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td> : <?php echo e($rt->email); ?></td>
        </tr>
    </table>
    <a href="/rt">Simpan</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/rt/show.blade.php ENDPATH**/ ?>