<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/kelurahan/store" method="post">
    <?php echo csrf_field(); ?>
    <tr>
        <td>Nama kelurahan</td>
        <input type="text" name="nama_kelurahan">
    </tr>
    <tr>
        <td>Nama Lurah</td>
        <input type="text" name="nama_lurah">
    </tr>
    <tr>
        <td>Masa Jabatan</td>
        <input type="text" name="masa_jabatan">
    </tr>
    <tr>
        <td>No Telp</td>
        <input type="text" name="no_telp">
    </tr>
    <tr>
        <td>Email</td>
        <input type="email" name="email">
    </tr>
    <tr>
        <button type="submit">Simpan</button>
    </tr>
</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/kelurahan/create.blade.php ENDPATH**/ ?>