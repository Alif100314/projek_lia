<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table>
        <thead>
            <th>NO</th>
            <th>Nama Petugas</th>
            <th>No Telpon</th>
            <th>Email</th>
            <th>Action</th>
        </thead>
       <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi=> $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($isi+1); ?></td>
                <td><?php echo e($a->nama_petugas); ?></td>
                <td><?php echo e($a->no_telp); ?></td>
                <td><?php echo e($a->email); ?></td>
                <td><a href="/petugas/edit/<?php echo e($a->id); ?>">Edit</a>
                    <a href="/petugas/destroy/<?php echo e($a->id); ?>">Hapus</a>
                </td>
            </tr>
           
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/petugas/create">Tambah</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/petugas/index.blade.php ENDPATH**/ ?>