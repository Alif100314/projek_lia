<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<table>
        <thead>
            <th>NO</th>
            <th>Tanggal Update Iuran</th>
            <th>Nominal Iuran</th>
        </thead>
       <?php $__currentLoopData = $iuran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi=> $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($isi+1); ?></td>
                <td><?php echo e($a->tanggal_update_iuran); ?></td>
                <td><?php echo e($a->nominal_iuran); ?></td>
                <td><a href="/iuran/edit/<?php echo e($a->id); ?>">Edit</a>
                    <a href="/iuran/destroy/<?php echo e($a->id); ?>">Hapus</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/iuran/create">Tambah</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/iuran/index.blade.php ENDPATH**/ ?>