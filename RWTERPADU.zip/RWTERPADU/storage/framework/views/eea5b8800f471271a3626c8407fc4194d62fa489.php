<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <thead>
            <th>NO</th>
            <th>Nama RT</th>
            <th>Masa Jabatan</th>
            <th>No Telpon</th>
            <th>Email</th>
            <th>Action</th>
        </thead>
       <?php $__currentLoopData = $rt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi=> $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($isi+1); ?></td>
                <td><?php echo e($a->nama_rt); ?></td>
                <td><?php echo e($a->masa_jabatan); ?></td>
                <td><?php echo e($a->no_telp); ?></td>
                <td><?php echo e($a->email); ?></td>
                <td><a href="/rt/edit/<?php echo e($a->id); ?>">Edit</a>
                    <a href="/rt/destroy/<?php echo e($a->id); ?>">Hapus</a>
                    <a href="/rt/show/<?php echo e($a->id); ?>">Show</a></td>
            </tr>
           
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <a href="/rt/create">Tambah</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\RWTERPADU\resources\views/rt/index.blade.php ENDPATH**/ ?>