<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RW extends Model
{
    protected $table ='r_w_s';
    protected $fillable =['nama_rw', 'masa_jabatan', 'no_telp', 'email'];
    protected $primaryKey ='id';
}
