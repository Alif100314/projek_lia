<?php

namespace App\Http\Controllers;

use App\Iuran;
use Illuminate\Http\Request;

class IuranController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $iuran = Iuran::all();
        return view('iuran.index', compact('iuran'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $iuran = Iuran::all();
        return view('iuran.create', compact('iuran'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $value = [
            'tanggal_update_iuran'=>$request ->tanggal_update_iuran,
            'nominal_iuran'=>$request ->nominal_iuran
        ];
        Iuran::create($value);
        return redirect('/iuran');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $iuran = Iuran::find($id);
        return view('iuran.edit', compact('iuran'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $modal = Iuran::find($id);
        $value = [
            'tanggal_update_iuran'=>$request ->tanggal_update_iuran,
            'nominal_iuran'=>$request ->nominal_iuran
        ];
        $modal->update($value);
        return redirect('/iuran');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $iuran = Iuran::destroy($id);
        return redirect('/iuran');
    }
}
