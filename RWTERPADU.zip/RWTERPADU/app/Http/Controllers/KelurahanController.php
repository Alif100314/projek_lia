<?php

namespace App\Http\Controllers;

use App\Kelurahan;
use Illuminate\Http\Request;

class KelurahanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = Kelurahan::all();
        return view('kelurahan.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $kelurahan = Kelurahan::all();
        return view('kelurahan.create', compact('kelurahan'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = [
            'nama_kelurahan'=>$request->nama_kelurahan,
            'nama_lurah'=>$request->nama_lurah,
            'masa_jabatan'=>$request->masa_jabatan,
            'no_telp'=>$request->no_telp,
            'email'=>$request->email
        ];
        Kelurahan::create($data);
        return redirect('/kelurahan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $kelurahan = kelurahan::find($id);
        return view('kelurahan.edit', compact('kelurahan'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $modal = kelurahan::find($id);
        $value = [
            'nama_kelurahan'=>$request ->nama_kelurahan,
            'nama_lurah'=>$request ->nama_lurah,
            'masa_jabatan'=>$request ->masa_jabatan,
            'no_telp'=>$request ->no_telp,
            'email'=>$request ->email
        ];
        $modal->update($value);
        return redirect('/kelurahan');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $kelurahan = kelurahan::destroy($id);
        return redirect('/kelurahan');
    }
}
