<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RT extends Model
{
    protected $table ='r_t_s';
    protected $fillable =['nama_rt', 'masa_jabatan', 'no_telp', 'email'];
    protected $primaryKey ='id';
}
